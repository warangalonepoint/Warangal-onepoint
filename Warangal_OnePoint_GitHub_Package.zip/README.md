# Warangal OnePoint Website Assets

This repository contains visual assets for the **Warangal OnePoint** website project.

## Contents

- Homepage banner featuring Warangal Arch, Ramappa, Thousand Pillar, and Bhadrakali temples
- Images for service pages:
  - Real Estate
  - Legal Services
  - Tourism & Temples
  - Corporate Solutions
  - Remote Assistance
- Official Logo: `Warangal OnePoint`

## Folder Structure

```
/assets/
├── A_high-resolution_digital_photograph_captures_a_re.png
├── A_high-resolution_digital_photograph_captures_an_a.png
├── A_digital_composite_image_features_landmarks_and_d.png
├── A_series_of_four_digital_photographs_showcases_his.png
├── A_logo_for_a_service_brand_named_"Warangal_OnePoin.png
```

---

Designed for use on digital platforms (website, mobile app, etc.)
